let screen = window.innerWidth

let big_cont = document.querySelector('.big-container')

if (screen<=667){
    big_cont.style.display = 'none'

}